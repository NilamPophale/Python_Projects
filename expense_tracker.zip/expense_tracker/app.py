# -*- coding: utf-8 -*-
"""
Created on Thu Aug  1 17:15:41 2024

@author: admin
"""

import sqlite3

def create_table():
    conn=sqlite3.connect('database.db')
    c=conn.cursor()
    c.execute('''
              CREATE TABLE IF NOT EXISTS expenses(
              id integer primary key autoincrement,
              date text not null,
              description text not null,
              amount real not null
              )
              ''')
              
    conn.commit()
    conn.close()
    
if __name__=='__main__':
    create_table()
    
    
from flask import Flask,render_template,redirect,request,url_for,flash
import sqlite3

app=Flask(__name__) 
app.secret_key='your_secret_key'

DATABASE='database.db'

def get_db_connection():
    conn=sqlite3.connect(DATABASE)
    conn.row_factory=sqlite3.Row
    return conn

def index():
    conn=get_db_connection()
    expenses=conn.execute('SELECT * FROM expenses').fetchall()
    conn.close()
    return render_template('index.html', expenses=expenses)

def add_expense():
    if request.method=='POST':
        date=request.form['date']
        description=request.form['description']
        amount=request.form['amount']
        
        if date and description and amount:
            conn=get_db_connection()
            conn.execute('TNSERT INTO expenses(date,description,amount)VALUES(?,?,?)'),(date,description,float(amount))
            conn.commit()
            conn.close()
            flash('Expense added successfully!')
            return redirect(url_for('index'))
        else:
            flash('All feild are required!')
    return render_template('add_expense.html')

def edit_expense(id):
    conn=get_db_connection()
    expense=conn.execute('SELECT * FROM expenses WHERE  id=?',(id,)).fetchone()
    
    if request.method=='POST':
        date=request.form['date']
        description=request.form['description']
        amount=request.form['amount']
        
        if date and description and amount:
            conn.execute('UPDATE expense SET date=?,description=?,amount=? WHERE ID=?',(date,description,float(amount)),id)
            conn.commit()
            conn.close()
            flash('Expense update successfully!')
            return redirect(url_for('index'))
        else:
            flash('All feild are required!')
            
    conn.close()
    return render_template('edit_expense.html', expense=expense)

def delete_expense(id):
    conn=get_db_connection()
    conn.execute('DELETE FROM expenses WHERE id=?',(id,))
    conn.commit()
    conn.close()
    flash('Expense deleted successfully!')
    return redirect(url_for('index'))

if __name__=='__main__':
    app.run(debug=True)

            
             
              
                  