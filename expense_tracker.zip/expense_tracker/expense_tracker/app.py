# -*- coding: utf-8 -*-
"""
Created on Thu Aug  1 17:15:41 2024

@author: admin
"""
# app.py
from flask import Flask, render_template, redirect, request, url_for, flash
import sqlite3

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Change this to a real secret key

DATABASE = 'database.db'

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def index():
    conn = get_db_connection()
    expenses = conn.execute('SELECT * FROM expenses').fetchall()
    conn.close()
    return render_template('index.html', expenses=expenses)

@app.route('/add', methods=['GET', 'POST'])
def add_expense():
    if request.method == 'POST':
        date = request.form['date']
        description = request.form['description']
        amount = request.form['amount']
        
        if date and description and amount:
            conn = get_db_connection()
            conn.execute('INSERT INTO expenses (date, description, amount) VALUES (?, ?, ?)',
                         (date, description, float(amount)))
            conn.commit()
            conn.close()
            flash('Expense added successfully!')
            return redirect(url_for('index'))
        else:
            flash('All fields are required!')
    return render_template('add_expense.html')

@app.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit_expense(id):
    conn = get_db_connection()
    expense = conn.execute('SELECT * FROM expenses WHERE id = ?', (id,)).fetchone()

    if request.method == 'POST':
        date = request.form['date']
        description = request.form['description']
        amount = request.form['amount']
        
        if date and description and amount:
            conn.execute('UPDATE expenses SET date = ?, description = ?, amount = ? WHERE id = ?',
                         (date, description, float(amount), id))
            conn.commit()
            conn.close()
            flash('Expense updated successfully!')
            return redirect(url_for('index'))
        else:
            flash('All fields are required!')
            
    conn.close()
    return render_template('edit_expense.html', expense=expense)

@app.route('/delete/<int:id>')
def delete_expense(id):
    conn = get_db_connection()
    conn.execute('DELETE FROM expenses WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    flash('Expense deleted successfully!')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)

    
