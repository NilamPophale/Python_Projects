# -*- coding: utf-8 -*-
"""
Created on Thu Aug  1 17:55:17 2024

@author: admin
"""

import sqlite3

def create_table():
    conn=sqlite3.connect('database.db')
    c=conn.cursor()
    c.execute('''
              CREATE TABLE IF NOT EXISTS invetory(
                  id integer primary key autoincrement,
                  name text not null,
                  quantity integer not null,
                  price real not null
                  )
              ''')
    conn.commit()
    conn.close()
    
if __name__=='__main__':
    create_table()
    
    