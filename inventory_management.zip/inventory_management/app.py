# -*- coding: utf-8 -*-
"""
Created on Thu Aug  1 18:06:25 2024

@author: admin
"""

from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3

app = Flask(__name__)
app.secret_key = 'your_secret_key'

DATABASE = 'database.db'

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def index():
    conn = get_db_connection()
    items = conn.execute('SELECT * FROM inventory').fetchall()
    conn.close()
    return render_template('index.html', items=items)

@app.route('/add', methods=['GET', 'POST'])
def add_item():
    if request.method == 'POST':
        name = request.form['name']
        quantity = request.form['quantity']
        price = request.form['price']
        
        if name and quantity.isdigit() and price.replace('.', '', 1).isdigit():
            conn = get_db_connection()
            conn.execute('INSERT INTO inventory (name, quantity, price) VALUES (?, ?, ?)', 
                         (name, int(quantity), float(price)))
            conn.commit()
            conn.close()
            flash('Item added successfully!')
            return redirect(url_for('index'))
        else:
            flash('All fields are required and must be valid!')
    
    return render_template('add_item.html')

@app.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit_item(id):
    conn = get_db_connection()
    item = conn.execute('SELECT * FROM inventory WHERE id = ?', (id,)).fetchone()

    if item is None:
        flash('Item not found!')
        return redirect(url_for('index'))

    if request.method == 'POST':
        name = request.form['name']
        quantity = request.form['quantity']
        price = request.form['price']
        
        if name and quantity.isdigit() and price.replace('.', '', 1).isdigit():
            conn.execute('UPDATE inventory SET name = ?, quantity = ?, price = ? WHERE id = ?',
                         (name, int(quantity), float(price), id))
            conn.commit()
            conn.close()
            flash('Item updated successfully!')
            return redirect(url_for('index'))
        else:
            flash('All fields are required and must be valid!')
    
    conn.close()
    return render_template('edit_item.html', item=item)

@app.route('/delete/<int:id>', methods=['POST'])
def delete_item(id):
    conn = get_db_connection()
    conn.execute('DELETE FROM inventory WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    flash('Item deleted successfully!')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True, use_reloader=False)
