# -*- coding: utf-8 -*-
"""
Created on Fri Aug  2 18:58:55 2024

@author: admin
"""

from flask import Flask,render_template,request,redirect,url_for

app=Flask(__name__)

dishes=[]

def index():
    return render_template('index.html')

def add_dish():
    if request.method=='POST':
        name=request.form['name']
        price=request.form['price']
        dishes.append(url_for({'name':name,'price':price}))
        return redirect(url_for('view_dishes'))
    return render_template('add_dish.html')

def view_dishes():
    return render_template('view_dishes.html', dishes=dishes)

if __name__=='__main__':
    app.run(debug=True)
                      