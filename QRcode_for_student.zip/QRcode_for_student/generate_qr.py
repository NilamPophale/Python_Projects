# -*- coding: utf-8 -*-
"""
Created on Thu Aug  1 19:41:34 2024

@author: admin
"""

import qrcode

def generate_qr(data,filename):
    qr=qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
        )
    
    qr.add_data(data)
    qr.make(fit=True)
    
    img=qr.make_image(fill='black',back_color='white')
    img.save(filename)
    print(f"QR code for '{data}' saved as '{filename}'")
    
if __name__=='__main__':
    generate_qr('student_001', 'student_001.png')
    generate_qr('student_002', 'student_002.png')
    
    