# -*- coding: utf-8 -*-
"""
Created on Thu Aug  1 20:12:51 2024

@author: admin
"""

import pandas as pd
import sys 
sys.path.append(r'C:\Users\admin\Desktop\QRcode_for_student')
from datetime import datetime
from scan_qr import scan_qr

def mark_attendance(student_id):
    try:
        df=pd.read_csv(r'C:\Users\admin\Desktop\attendance.csv')
    except FileNotFoundError:
        df=pd.DataFrame(columns=['Student_ID','Timestamp'])
        
    today=datetime.now().strftime('%y-%m-%d')
    if not df[(df['Student_ID']==student_id) & (df['Timestamp'].str.startswith(today))].empty:
        print('Attendance already marked for today.')
        return
    
    new_record={'Student_ID':student_id,'Timestamp':datetime.now().strftime('%y-%m-%d %H:%M:%S')}
    df=df.append(new_record,ignore_index=True)
    df.to_csv(r'C:\Users\admin\Desktop\attendance.csv',index=False)
    print(f'Attendance marked for student{student_id}')
    
def scan_and_mark_attendance():
    while True:
        student_id=scan_qr()
        if student_id:
            mark_attendance(student_id)
            
if __name__=='__main__':
    scan_and_mark_attendance()